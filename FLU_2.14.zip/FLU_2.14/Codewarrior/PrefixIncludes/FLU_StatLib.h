//=================================================================================
// FLU compiler prefix file for Codewarrior
//---------------------------------------------------------------------------------
#ifndef FLU_StatLib_H
	#define FLU_StatLib_H

	#define WIN32_LEAN_AND_MEAN
	#define WIN32_EXTRA_LEAN
	#define VC_EXTRA_LEAN
	#include <Win32Headers.h>

	#include <FL/FL_Export.h>

#endif
